Shell Floorplan Reference
=========================

This document provides the floorplan of the Small Shell.

Small Shell
-----------

|Small_shell_floorplan|

Recommendations
---------------

- The PCIS bus is physically located in SLR1 in SMALL_SHELL. Any customer
  logic interfacing with this bus should reside in SLR1.

.. |Small_shell_floorplan| image:: ./../../_static/small_shell_fp.png

`Back to HDK README <../README.html>`__
